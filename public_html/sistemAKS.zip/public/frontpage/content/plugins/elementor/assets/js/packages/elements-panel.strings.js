__('Elements', 'elementor');
__('Widgets', 'elementor');
__('Add Element', 'elementor');