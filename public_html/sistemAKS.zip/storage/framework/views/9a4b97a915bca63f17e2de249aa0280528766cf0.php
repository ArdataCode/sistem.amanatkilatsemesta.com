<h1
    <?php echo e($attributes->class(['filament-header-heading text-2xl font-bold tracking-tight'])); ?>

>
    <?php echo e($slot); ?>

</h1>
<?php /**PATH /home/1126019.cloudwaysapps.com/wduukqjrbn/public_html/resources/views/vendor/filament/components/header/heading.blade.php ENDPATH**/ ?>