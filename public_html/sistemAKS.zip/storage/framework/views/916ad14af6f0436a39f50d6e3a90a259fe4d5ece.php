<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH /home/1126019.cloudwaysapps.com/wduukqjrbn/public_html/vendor/filament/forms/src/../resources/views/components/group.blade.php ENDPATH**/ ?>