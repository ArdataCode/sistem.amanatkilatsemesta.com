<td
    <?php echo e($attributes->class([
            'filament-tables-cell',
            'dark:text-white' => config('tables.dark_mode'),
        ])); ?>

>
    <?php echo e($slot); ?>

</td>
<?php /**PATH /home/1126019.cloudwaysapps.com/wduukqjrbn/public_html/vendor/filament/tables/src/../resources/views/components/cell.blade.php ENDPATH**/ ?>