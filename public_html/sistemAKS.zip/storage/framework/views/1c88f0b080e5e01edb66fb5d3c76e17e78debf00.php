<td
    <?php echo e($attributes->class(['filament-tables-checkbox-cell w-4 whitespace-nowrap px-4'])); ?>

>
    <?php echo e($slot); ?>

</td>
<?php /**PATH /home/1126019.cloudwaysapps.com/wduukqjrbn/public_html/vendor/filament/tables/src/../resources/views/components/checkbox/cell.blade.php ENDPATH**/ ?>