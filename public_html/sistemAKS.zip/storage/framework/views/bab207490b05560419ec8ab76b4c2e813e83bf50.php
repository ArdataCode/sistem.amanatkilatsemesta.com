<h2
    <?php echo e($attributes->class(['filament-card-heading text-xl font-semibold tracking-tight'])); ?>

>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH /home/1126019.cloudwaysapps.com/wduukqjrbn/public_html/resources/views/vendor/filament/components/card/heading.blade.php ENDPATH**/ ?>